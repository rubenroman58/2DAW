var list = [1, '2', true];
var user = {
    name: "Ruben",
    age: 29,
    havePets: true
};
console.log(list[0], user.name);
