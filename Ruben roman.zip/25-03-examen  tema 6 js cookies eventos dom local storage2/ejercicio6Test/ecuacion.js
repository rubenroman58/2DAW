function ecuacion(a, b, c , x) {
    return a*x*x + b*x + c;
}
module.exports = ecuacion;